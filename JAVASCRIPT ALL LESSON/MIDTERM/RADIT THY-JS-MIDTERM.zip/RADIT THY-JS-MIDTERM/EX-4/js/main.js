const randomAuthor = () => {
   // TODO: random author name
   let list = document.querySelector('.user-list');

   let table = document.querySelector('table');

   let tr = document.querySelectorAll('tr');

   let th = document.querySelectorAll('th');

   let td = document.querySelectorAll('td');





}
console.log(randomAuthor)


// search movie title
const searchMovieTitle = () => {
    // TODO: search movie by title
    let user = document.querySelector('.user-list')
    console.log(user)

}


// Main
const tr = document.querySelectorAll('tbody tr');
const searchText = document.querySelector('#search');
const showTitle = document.querySelector('h1');

// TODO: Add event listeners on input search


// TODO: call randomAuthor function every 1000 milliseconds
