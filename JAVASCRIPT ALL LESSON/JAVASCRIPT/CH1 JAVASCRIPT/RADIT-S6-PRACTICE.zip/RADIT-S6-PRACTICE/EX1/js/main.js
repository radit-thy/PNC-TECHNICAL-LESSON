let text = "hello world [JavaScript] we [are] strong!";
// TODO: 
// YOUR CODE HERE
text = text.replace(/\[.*?\]/g, '');
console.log(text);

// output: hello world we strong!

