// case 1:
let arr = [1, 3, 6, 7, 9];
// TODO: 
// YOUR CODE HERE
let MaxNumber = arr[0];
for ( let i =0 ; i< arr.length; i++){
    if( arr[i]>MaxNumber){
        MaxNumber = arr[i];
    }
}
for (let i = 0; i< arr.length; i++){
    if (arr[i]<5){
        arr[i]= MaxNumber
    }
}
console.log(arr)
// output: [9, 9, 6, 7, 9]

