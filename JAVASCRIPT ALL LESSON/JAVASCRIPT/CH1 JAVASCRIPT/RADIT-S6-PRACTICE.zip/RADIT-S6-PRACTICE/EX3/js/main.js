let arrOne = [1, 3, 6, 7, 9];
let arrTwo = [4, 3, 5, 9, 1];
sum = 0;
for ( i = 0 ; i < arrTwo.length; i++){
    if( arrTwo[i] < arrOne[i]){
        arrTwo[i] = arrOne[i];
    }
}

console.log(arrTwo);