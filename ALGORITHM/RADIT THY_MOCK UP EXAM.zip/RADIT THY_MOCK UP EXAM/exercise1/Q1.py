
moneysOfWeekOne = [10, 15, 9, 20, 5, 30, 12]
result = 0
count = 0
for i in range(len(moneysOfWeekOne)):
    result += moneysOfWeekOne[i]
    count += 1
print(result)