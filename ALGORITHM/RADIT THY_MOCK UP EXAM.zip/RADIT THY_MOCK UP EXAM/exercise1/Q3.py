moneysOfWeekOne = [10, 15, 9, 20, 5, 30, 12]
reslt = 0
for i in range(len(moneysOfWeekOne)):
    print(moneysOfWeekOne[i])