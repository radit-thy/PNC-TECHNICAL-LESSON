fruit_store = ["banana", "mango", "coconut", "orange"]
result = len(fruit_store)
print('Type of fruit is: ',result,'types')

